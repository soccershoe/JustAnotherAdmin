﻿# From:  http://blogs.technet.com/b/filecab/archive/2009/05/11/customizing-file-management-tasks.aspx
# Save this file as MoveFile.ps1 to C:\Windows\System32

param([string]$FileSource, [string]$FolderDestination)

# Capture source folder name and filename
$SourceFileName = (Get-Item $FileSource).Name
$SourceFolder = (Get-Item $FileSource).DirectoryName

# Destination Path
$DestinationPath = $FolderDestination + "\" + $SourceFolder.Substring(3, $SourceFolder.Length-3)

# Check Destination Path, create if doesn't exist
$CheckedPath = Get-Item $DestinationPath -ErrorAction Ignore
if ($CheckedPath -eq $null) {
    New-Item -Path $DestinationPath -ItemType Directory 
}

# Move original file
Move-Item -Path $FileSource -Destination $DestinationPath