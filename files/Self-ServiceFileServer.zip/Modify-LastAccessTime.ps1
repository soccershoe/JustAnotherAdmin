﻿# Modify last access time

$ErrorActionPreference = "SilentlyContinue"

$a = Get-Date "2/13/2007 8:00 AM"

$b = Get-ChildItem "D:\Shares\depottest6\*.*" | where {($_.Name -ne "Archive")}

foreach ($i in $b){
    try {
        $i.LastAccessTime = $a
        $a = $a.AddMinutes(1)
        }
    catch [Exception] {
        "Didn't work: $i"
        }
    }
