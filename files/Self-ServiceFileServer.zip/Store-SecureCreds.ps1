﻿# Create the Password Hash #

$PlainPassword = "<ThePassWordHere>"
$SecurePassword = $PlainPassword | ConvertTo-SecureString -AsPlainText -Force

$key = (3,4,2,3,56,34,254,222,1,1,2,23,42,54,33,233,1,34,2,7,6,5,35,43)

$SecurePasswordKey = ConvertFrom-SecureString $SecurePassword -Key $key

#Output the hash and use this in the Create-Share script
$SecurePasswordKey