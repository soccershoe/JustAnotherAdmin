﻿#Create File Management Custom Expiration Task
# From:  http://blogs.technet.com/b/filecab/archive/2009/05/11/customizing-file-management-tasks.aspx

$Command = "C:\Windows\System32\WindowsPowerShell\v1.0\PowerShell.exe"
$CommandParameters = "`"C:\Windows\System32\MoveFile.ps1 -FileSource '[Source File Path]' -FolderDestination 'E:\FileExpiration'`""
$Action = New-FSRMFmjAction -Type Custom -Command $Command -CommandParameters $CommandParameters -SecurityLevel LocalSystem -WorkingDirectory "C:\Windows\System32\WindowsPowerShell\v1.0\"
$Condition = New-FsrmFmjCondition -Property "File.DateLastAccessed" -Condition LessThan -Value "Date.Now" -DateOffset -365
$Schedule = New-FsrmScheduledTask -Time (Get-Date) -Weekly Sunday
New-FsrmFileManagementJob -Name "Shared File Expiration" -Namespace "D:\Shares" -Action $Action -Condition $Condition -Schedule $Schedule -ReportFormat DHtml
