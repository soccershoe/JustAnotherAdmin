﻿Function Create-Share
{


# Load Prerequisites
# Powershell v4 or higher required
# Imamami Powershell Plugin plus Expiration Option
Import-Module ActiveDirectory
add-PSSnapIn Imanami.Groups.Management.PowerShell.Admin


# Get the user input
$reqHDUser = Read-Host -Prompt "Your Username"
$reqUsername = Read-Host -Prompt "The Share requestor's Username"
$reqShareName = Read-Host -Prompt "Requested Share Name"
$reqAddOwner = Read-Host -Prompt "Add an additional Owner Username"


# Get and Decrypt Service Account Credentials
$SecurePasswordKey = '76492d1116743f0423413b16050a5345MgB8AGEAMgBMADMAVABQAGoAdABOAEkAMQBtAEwAKwA4ADMARgB5AFkAQwB0AGcAPQA9AHwANgA5AGIAZABlADAAOQA4ADAAYgA3AGUANAAyAGIANwBjADIAYwBkADgAYgBjADIANQA4ADgANABjAGMAMgA4ADkANgA2ADMAYgA3ADYAYgBiAGMAZgBkADgAYQBkADIAMAA2ADkAZQAxAGMANQA4ADcAZgA1ADcAOQAwADUAMgA='
$key = (3,4,2,3,56,34,254,222,1,1,2,23,42,54,33,233,1,34,2,7,6,5,35,43)
$SecurePassword = ConvertTo-SecureString -String $SecurePasswordKey -Key $key
$Usr = "domain.com\serviceaccount"
$Cred = New-Object System.Management.Automation.PsCredential $Usr,$SecurePassword


# Validate User Input
If (Get-ADUser -Filter "SamAccountName -eq '$reqHDUser'") {Write-Host "$reqHDUser exists"}
Else {Write-Host "$reqHDUser does not exist. Please use a domain username." ; Break}

If (Get-ADUser -Filter "SamAccountName -eq '$reqUsername'") {Write-Host "$reqUsername exists"}
Else {Write-Host "$reqUsername does not exist. Please use a domain username." ; Break}

If (Get-ADUser -Filter "SamAccountName -eq '$reqAddOwner'") {Write-Host "$reqAddOwner exists"}
Else {Write-Host "$reqAddOwner does not exist. Please use a domain username." ; Break}


# Additional Variables
$ServerName = $env:computername
$RequestorEmail = (Get-ADUser -Identity $reqUsername -Server adservername -Properties mail).mail
$Path = "D:\Shares\$reqShareName"
$FileExpirationPath = "E:\FileExpiration\Shares\$reqShareName"
$ModGroup = "Depot-$reqShareName-MOD"
$ReadGroup = "Depot-$reqShareName-READ"


# Create and Enter PSSession to File Server
$Session = New-PSSession -ComputerName fileshareserver -Credential $Cred


# Validate that Share doensn't already exist
$DoesShareExist = Invoke-Command -Session $Session -ScriptBlock {
    $ShareExist = Test-Path $Using:Path
    Return $ShareExist
    }
If ($DoesShareExist -eq "True") {Write-Host "The share $reqShareName already exists. Please choose another name." ; Break}
Else {Write-Host "$reqShareName does not yet exist. Continuing creation."}


# Check if Security Groups already exist
$Group = Get-ADGroup -Filter {SamAccountName -eq $ModGroup} -SearchBase "OU=Security Groups,DC=DOMAIN,DC=com"
If ($group -eq $Null) {Write-Host "Group $ModGroup does not exist. Please continue."}
Else {Write-Host "Group $ModGroup Exists" ; Break}

$Group = Get-ADGroup -Filter {SamAccountName -eq $ReadGroup} -SearchBase "OU=Security Groups,DC=DOMAIN,DC=com"
If ($group -eq $Null) {Write-Host "Group $ReadGroup does not exist. Please continue."}
Else {Write-Host "Group $ReadGroup Exists" ; Break}


# Create the New Security Groups
#New-ADGroup -Name $ModGroup -SamAccountName $ModGroup -GroupCategory Security -GroupScope Global -DisplayName $ModGroup -Path "OU=Security Groups,DC=DOMAIN,DC=com" -Description "Created for MODIFY access to \\Depot\$ShareName" -Server adservername -Credential $Cred
#New-ADGroup -Name $ReadGroup -SamAccountName $ReadGroup -GroupCategory Security -GroupScope Global -DisplayName $ReadGroup -Path "OU=Security Groups,DC=DOMAIN,DC=com" -Description "Created for READ access to \\Depot\$ShareName" -Server adservername -Credential $Cred
New-Group -name $ModGroup -SamAccountName $ModGroup -Type 'Security' -GroupScope 'Universal Group' -SecurityType Semi_Private -ManagedBy (Get-ADUser $reqUsername).DistinguishedName -OrganizationalUnit 'OU=Security Groups,DC=DOMAIN,DC=com' -Credential $cred -DomainServer adservername -AdditionalOwners (Get-ADUser $reqAddOwner).DistinguishedName
set-group -Identity $ModGroup -ExpirationPolicy 60
set-group -Identity $ModGroup -IsExpired true
set-group -Identity $ModGroup -IsExpired false
New-Group -name $ReadGroup -SamAccountName $ReadGroup -Type 'Security' -GroupScope 'Universal Group' -SecurityType Semi_Private -ManagedBy (Get-ADUser $reqUsername).DistinguishedName -OrganizationalUnit 'OU=Security Groups,DC=DOMAIN,DC=com' -Credential $cred -DomainServer adservername -AdditionalOwners (Get-ADUser $reqAddOwner).DistinguishedName
set-group -Identity $ReadGroup -ExpirationPolicy 60
set-group -Identity $ReadGroup -IsExpired true
set-group -Identity $ReadGroup -IsExpired false


#Validate the the group has been created for the commands that follow
Do {
    $strQuit = Get-ADGroup -Filter {sAMAccountName -eq $ModGroup} -Server adservername
    If ($strQuit -eq $Null) {write-host "checking group creation..."; start-sleep 15}
        else {Write-Host "Group created. Continuing Script."}
    }
Until ($strQuit -ne $Null)

Do {
    $strQuit = Get-ADGroup -Filter {sAMAccountName -eq $ReadGroup} -Server adservername
    If ($strQuit -eq $Null) {write-host "checking group creation..."; start-sleep 15}
        else {Write-Host "Group created. Continuing Script."}
    }
Until ($strQuit -ne $Null)


# Add User to Security Group
Add-ADGroupMember -Identity $ModGroup -Members $reqUsername -Server adservername -Credential $Cred
Add-ADGroupMember -Identity $ReadGroup -Members $reqUsername -Server adservername -Credential $Cred
Add-ADGroupMember -Identity $ModGroup -Members $reqAddOwner -Server adservername -Credential $Cred
Add-ADGroupMember -Identity $ReadGroup -Members $reqAddOwner -Server adservername -Credential $Cred


# Create the Folder to be shared
Invoke-Command -Session $Session -ScriptBlock {New-Item -Path $Using:Path -ItemType Directory}


# Disable Inheritance & Apply Default Perms
New-PSDrive -Name PSDrive -PSProvider FileSystem -Root "\\fileservername\d$\Shares" -Credential $Cred

$Acl = Get-Acl "PSDrive:\$reqShareName" 
$Acl.SetAccessRuleProtection($True, $False)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators", "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM", "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule( ((Get-ADGroup "Domain Admins" -Server adservername).sid), "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule( ((Get-ADGroup $ModGroup -Server adservername).sid), "Modify", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule( ((Get-AdGroup $ReadGroup -Server adservername).sid), "ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
Set-Acl -Path "PSDrive:\$reqShareName" -AclObject $Acl

Remove-PSDrive -Name PSDrive


# Create Share#
Invoke-Command -Session $Session -ScriptBlock {New-SmbShare -Name $Using:reqShareName -Path $Using:Path -CachingMode BranchCache -FullAccess Everyone -Description "$Using:reqShareName description" -EncryptData $False -FolderEnumerationMode AccessBased}


# Apply Quota
Invoke-Command -Session $Session -ScriptBlock {New-FsrmQuota -path $Using:Path -Template "20GB Limit with 5GB Extension"}


# Set Share Management Properties
Invoke-Command -Session $Session -ScriptBlock {Set-FsrmMgmtProperty -Namespace $Using:Path -Name "FolderUsage_MS" -Value "User Files|Group Files"}
Invoke-Command -Session $Session -ScriptBlock {Set-FsrmMgmtProperty -Namespace $Using:Path -Name "FolderOwnerEmail_MS" -Value "$reqUsername@domain.com"}


# Create Share Reports
Invoke-Command -Session $Session -ScriptBlock {$FsrmTask = New-FsrmScheduledTask -Time "01:00" -Monthly 1 ; New-FsrmStorageReport -Name "$Using:reqShareName Quota Usage" -Namespace $Using:Path -ReportType QuotaUsage -ReportFormat DHTML -Schedule $FsrmTask -MailTo $Using:RequestorEmail}


# Create the Directory Junction
Invoke-Command -Session $Session -ScriptBlock {cmd /c mklink /J $Using:Path\Archive $Using:FileExpirationPath}


# Create Archive Folder and FileExpiration Directory Junction Folder
Invoke-Command -Session $Session -ScriptBlock {New-Item -Path $Using:FileExpirationPath -ItemType Directory}


# Wait 10 seconds for Archive folder to complete creation
Start-Sleep -s 10


# Create Permissions for the Archive Directory Junction
$Acl = Get-Acl "\\fileservername\D$\Shares\$reqShareName\Archive"
$Acl.SetAccessRuleProtection($True, $False)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators", "ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM", "ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule(( (Get-ADGroup "Domain Admins" -Server chcxadcsea003).sid), "ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule(( (Get-ADGroup $ModGroup -Server chcxadcsea003).sid), "ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule(( (get-adgroup $ReadGroup -Server chcxadcsea003).sid), "ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
Set-Acl -Path "\\fileservername\D$\Shares\$reqShareName\Archive" -AclObject $Acl


# Create Permissions for the FileExpiration folder
$Acl = Get-Acl "\\fileservername\E$\FileExpiration\Shares\$reqShareName"
$Acl.SetAccessRuleProtection($True, $False)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators", "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM", "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule(( (Get-ADGroup "Domain Admins" -Server chcxadcsea003).sid), "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
$Rule = New-Object System.Security.AccessControl.FileSystemAccessRule(( (Get-ADGroup $ModGroup -Server chcxadcsea003).sid), "ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$Acl.AddAccessRule($Rule)
Set-Acl -Path "\\fileservername\E$\FileExpiration\Shares\$reqShareName" -AclObject $Acl


# Remove PSSession to File Server
Get-PSSession | Remove-PSSession


#Send Share Creation Email
$ShareComplete = "<HTML><HEAD><META http-equiv=""Content-Type"" content=""text/html; charset=iso-8859-1"" /><TITLE></TITLE></HEAD>"
$ShareComplete += "<BODY bgcolor=""#FFFFFF"" style=""font-size: Small; font-family: Calibri; color: #000000""><P>"
$ShareComplete += "Dear <font color=black>$RequestorEmail</font><br>"
$ShareComplete += "<br>"
$ShareComplete += "Congratulations!  Your new Share, <b><a href=\\Depot\$reqShareName>\\Depot\$reqShareName</a></b> has been created.<br>"
$ShareComplete += "You may need to allow permissions to replicate up to an hour before you are successfully able to log into your share.  You may also need to log off your workstation as well for the permissions to apply.<br>"
$ShareComplete += "<br>"
$ShareComplete += "As the Share owner, you will be the approver for who has access to your Share.  Please go to the GroupID Security Group Portal here_ to grant additional users Read or Modify access to your Share.<br>"
$ShareComplete += "Your Share also comes with a <b>10GB quota</b>.  You will be receiving <b>Monthly Quota Reports</b> letting you know how much space is used.<br>"
$ShareComplete += "Please contact the GSD to update your Share with additional Owners who will have access to update Share access for users and receive the Quota reports.<br>"
$ShareComplete += "<br>"
$ShareComplete += "Access to your share is self-service and can be managed by adding your users to these two groups:<br>"
$ShareComplete += "<b>$ModGroup</b> - Will grant users the ability to Add, Delete and Modify items in your share.  This group also has access to the Archive folder in your share.<br>"
$ShareComplete += "<b>$ReadGroup</b> - Will grant users the ability to Read the items in your share.<br>"
$ShareComplete += "<br>"
$ShareComplete += "The <b>Archive</b> folder in your Share is a unique location where your files will automatically get moved too if they have not been accessed in more than 365 days.  Files in this location do not count against your share quota.  The Archive process is handled automatically.<br>"
$ShareComplete += "<br>"
$ShareComplete += "File and Folder <b>Restores</b> are also self-service and can be completed by selecting the Properties on a file or folder and going to the 'Previous Versions' tab. Select what you need and click 'Restore'.<br>"
$ShareComplete += "<br>"
$ShareComplete += "If you have any further questions please contact the <a href=http://helpdesk.domain.com/help.aspx target=""_blank"">GSD</a>.<br>"
Send-MailMessage -to $RequestorEmail -from "FileAdmin@domain.com" -subject "Your Share Request" -body $ShareComplete -BodyAsHtml -SmtpServer mailhost.sea.corp.expecn.com

Write-Host
Write-Host "Share Setup Complete."
}


# Get the Share Owners for the requested Share
Function Get-ShareOwners {
    $reqShareName = Read-Host -Prompt "Requested Share Name"
    $reqHDUser = Read-Host -Prompt "Your Username"
    $Encrypted = Get-Content c:\temp\encrypted_password.cred | ConvertTo-SecureString
    $Cred = New-Object -typename System.Management.Automation.PSCredential -argumentlist "domain.com\adminuser",$Encrypted
    $Session = New-PSSession -ComputerName fileservername -Credential $Cred
    Invoke-Command -Session $Session -ScriptBlock {Write-Host  ; Write-Host "Share Owner(s):" ; ((Get-FsrmMgmtProperty -Namespace "D:\Shares\$Using:reqShareName" -Name "FolderOwnerEmail_MS").PropertyValue).Value}
    Get-PSSession | Remove-PSSession
}


# Get All Shares on the Server
Function Get-AllShares {
    $reqHDUser = Read-Host -Prompt "Your Username"
    $Encrypted = Get-Content c:\temp\encrypted_password.cred | ConvertTo-SecureString
    $Cred = New-Object -typename System.Management.Automation.PSCredential -argumentlist "domain.com\adminuser",$Encrypted
    $Session = New-PSSession -ComputerName fileservername -Credential $Cred
    Invoke-Command -Session $Session -ScriptBlock {Get-SMBShare | select Name,Description | ft}
    Get-PSSession | Remove-PSSession
}


# Create Interactive Menu
[int]$xMenuChoiceA = 0

while ( $xMenuChoiceA -lt 1 -or $xMenuChoiceA -gt 4 ){
Write-host "1. Create a new Share" -Fore Yellow
Write-host "2. List Share Owner(s)" -Fore Yellow
Write-host "3. Update Share Owner(s)" -Fore Yellow
Write-Host "4. List all Shares" -Fore Yellow
Write-host "5. Quit and exit" -Fore Yellow
[Int]$xMenuChoiceA = read-host "Please enter an option 1 to 5..." }

Switch( $xMenuChoiceA ){
  1{Create-Share}
  2{Get-ShareOwners}
  3{Write-Host "This feature to be completed"}
  4{Get-AllShares}
default{}
}
