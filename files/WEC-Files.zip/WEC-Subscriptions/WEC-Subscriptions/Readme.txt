This folder contains the .XML files needed to create the event subscriptions.
