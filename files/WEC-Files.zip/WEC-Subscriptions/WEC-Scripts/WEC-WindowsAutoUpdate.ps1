﻿# Script to auto-update Windows from Microsoft Update servers
Import-Module pswindowsupdate
# register ms update service
Add-WUServiceManager -ServiceID "7971f918-a847-4430-9279-4a52d1efe18d" -Confirm:$false
Install-WindowsUpdate -AcceptAll -MicrosoftUpdate -AutoReboot