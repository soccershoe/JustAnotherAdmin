﻿# Move the new Eventlogs to the D: drive

Stop-Service wecsvc
$xml = wevtutil el | select-string -pattern "WEC"
foreach ($subscription in $xml) { 
wevtutil sl $subscription /lfn:D:\WEC-EventLogs\$subscription.evtx
}
Start-Service wecsvc
