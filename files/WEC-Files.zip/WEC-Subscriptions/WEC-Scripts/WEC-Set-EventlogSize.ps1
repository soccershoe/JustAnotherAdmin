﻿# Set the EventLog sizes to 2GB

$xml = wevtutil el | select-string -pattern "WEC"
foreach ($subscription in $xml) { 
wevtutil sl $subscription /ms:2194304000
}