This folder contains various scripts to maintain WEF.

WEC-Registry-Grooming.ps1 - Powershell script for the scheduled grooming task.
WEC-Registry-Grooming.xml - Export/backup of the scheduled task.  Import to create the task.
WEC-Deploy-Subscriptions.ps1 - Create new Subscriptions.  Used during setup of new WEC server.
WEC-Move-Eventlogs.ps1 - Move the new Event Logs to the D: drive from the default.  Used during setup of new WEC server.
WEC-HTTPErr-Grooming.ps1 - Powershell script to remove old HTTPErr files.  These will eventually fill up the drive if not removed.
WEC-HTTPErr-Grooming.xml - Export/backup of the scheduled task.  Import to create the task.
WEC-Set-EventlogSize.ps1 - Change log size for each file.  Used during WEC server setup.
Weekly Reboot.xml - Weekly reboot of server.  Export/backup of the scheduled task.  Import to create the task.

WUInstallation\pswindowsupdate - Powershell Module folder to automate Windows Updates.  Copy folder to "C:\Windows\System32\WindowsPowerShell\v1.0\Modules"
WEC-WindowsAutoUpdate.ps1 - Powershell script to automatically apply Windows Updates from Microsoft Update and reboot.
WEC-WindowsAutoUpdate.xml - Export/backup of the scheduled task.  Import to create the task.

