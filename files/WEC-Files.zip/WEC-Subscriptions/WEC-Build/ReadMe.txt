This folder contains the files and apps needed to build and maintain the .DLL and .MAN files (minus the SDK) for creating custom event channels (or event log locations).
