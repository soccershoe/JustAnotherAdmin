File list
-------------
servers.txt - Servers that'll get updated via the script.
Get-TLS.ps1 - Retrieve TLS registry entries. 
Set-TLS.ps1 - Sets only registry entries to enable TLS1.1/1.2.  No disabling.
All-TLS.ps1 - Sets registry entries to Disable legacy and Enable TLS1.1/1.2.  
BatchGet-TLS.ps1 - Retrieve TLS registry entries from servers in servers.txt.
BatchSet-TLS.ps1 - Sets only registry entries to enable TLS1.1/1.2 to servers in servers.txt.  No disabling.
BatchAll-TLS.ps1 - Sets registry entries to Disable legacy and Enable TLS1.1/1.2 to server in servers.txt

Default Dir
-------------
Default folder I'm using is C:\temp.


General
-------------
* The Set,Get,All-TLS.ps1  Are meant to be run individually on each server locally.
* The Batch__.ps1 loads the servers.txt and serially connects to each of the entries in servers.txt to execute that command.  
* In the Batch__.ps1 it loads the associated Set/Get/All-TLS.ps1 that's been cast as a Scriptblock. And then uses that scriptblock in the Invoke-Command.  Enables loading up that original script that's been tested and re-using that in a PSremoting session.



Run the Batch__.ps1 file to execute.


I'm sure this could all be much more elegant.  Feel free to change it up as needed.